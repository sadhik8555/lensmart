package com.example.demo.controller;

import java.awt.print.Book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.BookService;

import ch.qos.logback.core.model.Model;

@RestController
public class BookController {

	@Autowired
	BookService bookService;
	
	
	@GetMapping("/books")
	public void getBookInfo() {
		
		System.out.println("*Start-BookController**-getBookInfo()-***");
		
		bookService.getFromProperties();
		
        System.out.println("*End-BookController**-getBookInfo()-***");
	}
	
	
	
}
