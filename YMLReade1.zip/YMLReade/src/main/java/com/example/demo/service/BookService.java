//package com.example.demo.service;
//
//
//
//import java.util.Arrays;
//
//import java.util.List;
//
//import java.util.Set;
//
//import org.springframework.beans.factory.annotation.Value;
//
//import org.springframework.stereotype.Component;
//
//
//@Component
//public class BookService {
//
//	@Value("${example.bookdescription}")
//	private String bookdescription;
//	
//	@Value("${example.bookid}")
//	private int[] bookidarray;
//	
//	@Value("${example.bookprice}")
//	private List<Integer> bookpriceList;
//	
//	@Value("${example.bookname}")
//	private Set<String> booknameSet;
//	
//	public void getFromProperties() {
//		
//		System.out.println("*Start-BookService**-getFromProperties()-***");
//	
//	    System.out.println("Description - " + bookdescription);
//	    
//	    System.out.println("Book Id as Integer Array - " + Arrays.toString(bookidarray));
//	    
//	    System.out.println("Book Price as Integer List - " + bookpriceList);
//
//	    System.out.println("Book Name as String Set  - " + booknameSet);
//	
//        System.out.println("*End-BookService**-getFromProperties()-***");
//}
//}
