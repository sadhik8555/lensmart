package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Books;
import com.fasterxml.jackson.annotation.JsonIgnore;

import ch.qos.logback.core.model.Model;

@RestController
public class BookController {

	@Autowired
	Books book;
	 
	
	@JsonIgnore
    @GetMapping("/")
    public Books bookInfo() {
         
        System.out.println("Book title: " + book.getTitle());
        System.out.println("Book id: " + book.getId());
        System.out.println("Book price: " + book.getPrice());
        
       
		
        return book;
		
        
         
        
    }
}