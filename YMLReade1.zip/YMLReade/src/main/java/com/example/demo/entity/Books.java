package com.example.demo.entity;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties(prefix = "book")
@Configuration("Book")
public class Books {
	
	private String title;
	private int id;
	private int price;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Books() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Books(String title, int id, int price) {
		super();
		this.title = title;
		this.id = id;
		this.price = price;
	}

	
	
}
