package com.example.demo.service;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class BookService {
	
	@Value("${example.bookdescription : This is my book }")
	private String defaultbookdescription;
	
	@Value("${example.bookid : 11 , 12 , 13 , 14 , 15 }")
	private int[] bookid;
	
	@Value("${example.bookprice : 100 , 200 , 300 , 400 , 500 }")
	private List<Integer> bookprice;
	
	@Value("${example.bookname : Comic , Hooror , Love , Cooking , Historical }")
	private Set<String> bookname;
	
	public void getDefaultDataFromProperties() {
		
		System.out.println("*Start-BookService**-getDefaultDataFromProperties()-***");
		
	    System.out.println("Book Description As String - " + defaultbookdescription);
	    
	    System.out.println("Book Id as Integer Array - " + Arrays.toString(bookid));
	    
	    System.out.println("Book Price as Integer List - " + bookprice);

	    System.out.println("Book Name as String Set  - " + bookname);

        System.out.println("*End-BookService**-getDefaultDataFromProperties()-***");
}
		
		

}
